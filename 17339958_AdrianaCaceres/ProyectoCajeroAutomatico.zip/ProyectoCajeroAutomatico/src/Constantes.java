public class Constantes {
    public static final double MONTO_INICIAL = 5500.88;
    public static final double TIPO_CAMBIO_INICIAL = 4.00;
}
